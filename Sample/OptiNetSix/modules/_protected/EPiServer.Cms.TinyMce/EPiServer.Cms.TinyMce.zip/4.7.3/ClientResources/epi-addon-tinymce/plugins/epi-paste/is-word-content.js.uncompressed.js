﻿define("epi-addon-tinymce/plugins/epi-paste/is-word-content", [], function () {
    function isWordContent(content) {
        return (
            (/<font face="Times New Roman"|class="?Mso|style="[^"]*\bmso-|style='[^']*\bmso-|w:WordDocument/i).test(content) ||
            (/class="OutlineElement/).test(content) ||
            (/id="?docs\-internal\-guid\-/.test(content))
        );
    }

    return isWordContent;
});
