define("epi-cms/contentediting/command/ContentAreaItemBlockEdit", [
    "dojo/_base/declare",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
    "dojo/Evented",

    "dojox/html/entities",

    "epi/dependency",
    "epi/shell/DestroyableByKey",

    "epi/shell/command/_Command",

    "epi-cms/contentediting/DialogPositionAdjust",
    "epi-cms/contentediting/inline-editing/InlineEditBlockDialog",
    "epi-cms/contentediting/inline-editing/LocalBlockEditFormContainer",
    "epi-cms/_ContentContextMixin",

    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons",
    "epi/i18n!epi/nls/episerver.cms.contentapproval.command.requestapproval",

    "epi/i18n!epi/cms/nls/episerver.shared.action"
], function (
    declare,
    on,
    topic,
    when,
    Evented,

    htmlEntities,

    dependency,
    DestroyableByKey,

    _Command,

    DialogPositionAdjust,
    InlineEditBlockDialog,
    LocalBlockEditFormContainer,
    _ContentContextMixin,
    resources,
    toolbarButtonsRes,
    requestapprovalRes,

    actionStrings
) {

    return declare([_Command, Evented, DestroyableByKey, _ContentContextMixin], {
        // summary:
        //      Inline-edit command for local ContentArea blocks stored in ContentArea
        // tags:
        //      internal xproduct

        label: resources.inlineblockedit,

        iconClass: "epi-iconPenQuick",

        isContentAreaReadonly: false,

        // suppressOverlayAdjustments: [public] Boolean
        //      Flag which indicates that all overlay adjustments should not be performed. It might be useful when showing another overlay or dialog (e.g. TinyMCE full screen)
        suppressOverlayAdjustments: false,

        postscript: function () {
            this.inherited(arguments);

            this._dialogPositionAdjust = new DialogPositionAdjust();
            this.own(this._dialogPositionAdjust);
        },

        _execute: function () {
            // summary:
            //    Open the inline edit block dialog
            // tags:
            //      protected

            var dialog = new InlineEditBlockDialog({
                title: htmlEntities.encode(this.model.name),
                mainCommand: this.mainCommand,
                suppressOverlayAdjustments: this.suppressOverlayAdjustments
            });

            var form;

            function updateMainCommandVisibility() {
                if (!dialog) {
                    return;
                }
                dialog.toggleDisabledSaveButton(!form.get("isDirty"));
            }

            form = new LocalBlockEditFormContainer({}, dialog.content, "last");
            dialog.own(form);

            this._getMetadata(this.model.contentTypeId).then(function (metadata) {
                form.set("contentLink", this.parentContentLink);
                when(form.set("metadata", metadata)).then(function () {
                    form.set("value", this.model.inlineBlockData);
                }.bind(this));
            }.bind(this));

            if (this.model.get("readOnly")) {
                form.set("readOnly", true);
            }

            dialog.own(on(form, "FormCreated", function () {
                if (form.model && !form._model.canChangeContent()) {
                    dialog.hideSaveButton();
                    dialog.set("closeText", "Close");
                }

                dialog.show();
                updateMainCommandVisibility();

            }.bind(this)));

            dialog.own(on(form, "isDirty", updateMainCommandVisibility.bind(form)));
            dialog.own(on(dialog, "execute", function () {
                this.emit("save", form.get("value"));
            }.bind(this)));

            dialog.own(on(dialog, "hide", function () {
                this._dialogPositionAdjust.cleanup();
            }.bind(this)));

            this._dialogPositionAdjust.adjustDialogPosition(dialog);
        },

        _getMetadata: function (contentTypeId) {
            return when(this.getCurrentContent()).then(function (content) {
                this.parentContentLink = content.contentLink;
                this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
                return this.metadataManager.getMetadataForType("EPiServer.Core.ContentData", {
                    parentLink: content.contentLink,
                    contentTypeId: contentTypeId
                });
            }.bind(this));
        },

        updateModel: function (model) {
            // summary:
            //      Updates model and returns result from onModelChange callback
            // tags:
            //      internal

            this.model = model;
            return this._onModelChange();
        },

        _onModelChange: function () {
            // summary:
            //      Updates isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model;

            if (!item || !item.inlineBlockData) {
                this.set("isAvailable", false);
                return;
            }

            this.set("canExecute", true);
            this.set("isAvailable", true);

            if (this.model instanceof Array) {
                // this command should be available only if one item selected
                // because it should be disabled when multiple blocks are selected
                // like in Assets pane
                if (this.model.length === 1) {
                    this.model = this.model[0];
                } else {
                    this.model = null;
                }
            }

            if (!this.model) {
                this.set("canExecute", false);
                return;
            }

            if (this.model.isOverlayInitialized === false) {
                return;
            }

            if (!this.isContentAreaReadonly) {
                this.set("label", actionStrings.edit);
                this.set("iconClass", "epi-iconPen");
            } else {
                this.set("label", actionStrings.view);
                this.set("iconClass", "epi-iconSearch");
            }
        }
    });
});
