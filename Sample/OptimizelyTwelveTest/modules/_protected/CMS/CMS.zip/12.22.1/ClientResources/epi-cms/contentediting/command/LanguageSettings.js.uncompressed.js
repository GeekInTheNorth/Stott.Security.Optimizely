define("epi-cms/contentediting/command/LanguageSettings", [
    "require",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",
    "dojo/Deferred",
    "epi/dependency",
    "epi-cms/contentediting/ContentActionSupport",
    "epi/shell/command/_Command",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/ApplicationSettings",

    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.contentdetails.command.languagesettings",
    "epi/i18n!epi/shell/nls/edit.languagesettings",
    "epi/i18n!epi/shell/nls/button",
    "epi/i18n!epi/nls/episerver.shared"
], function (
    moduleRequire,
    declare,
    lang,
    topic,
    when,
    Deferred,
    dependency,
    ContentActionSupport,
    _Command,
    Dialog,
    ApplicationSettings,
    commandResources,
    uiResources,
    buttonResources,
    sharedResources) {

    function LanguageSettingsViewModel(store, contentLink) {

        return {
            getLanguageSettings: function () {
                return store.get(contentLink);
            },
            saveLanguageSettings: function (settings) {
                return store.executeMethod("UpdateLanguageSettings", contentLink, {
                    availableLanguages: settings.availableLanguages,
                    id: contentLink,
                    inheritSettings: settings.inheritSettings,
                    replacementLanguages: settings.replacementLanguages,
                    fallbackLanguages: settings.fallbackLanguages
                });
            },
            onMessage: function (message) {
                // callback
            },
            onReadOnly: function (isReadOnly) {
                // callback
            }
        };
    }

    return declare([_Command], {
        // summary:
        //      Toggles permanent in use notification on/off.
        //
        // tags:
        //      internal
        name: "LanguageSettings",
        label: commandResources.label,
        tooltip: commandResources.tooltip,
        store: null,

        constructor: function () {
            this.store = dependency.resolve("epi.storeregistry").get("epi.cms.languagesettings");
            this.contentStore = dependency.resolve("epi.storeregistry").get("epi.cms.content.light");
        },

        _execute: function () {
            // summary:
            //		Toggles the value of the given property on the model.
            // tags:
            //		protected

            moduleRequire(["epi-cms-react/components/language-settings-widget", "xstyle/css!epi-cms-react/components/language-settings-widget.css"], function (LanguageSettingsWidget) {
                when(this.contentStore.get(this.model.contentData.parentLink)).then(function (parentContent) {
                    var resources = Object.assign({}, uiResources,
                        {
                            heading: lang.replace(uiResources.heading, [this.model.contentData.name]),
                            inheritsettings: parentContent ? lang.replace(uiResources.inheritsettings, [parentContent.name]) : uiResources.inheritsettings,
                            change: buttonResources.change,
                            save: buttonResources.save,
                            ok: buttonResources.ok,
                            cancel: buttonResources.cancel
                        });
                    var contentLink = this.model.contentData.contentLink;
                    var model = LanguageSettingsViewModel(this.store, contentLink);

                    var dialog;
                    model.getLanguageSettings().then(function (settings) {
                        var content = new LanguageSettingsWidget({
                            model: model,
                            resources: resources,
                            defaultSettings: settings,
                            helpLink: ApplicationSettings.userGuideUrl + "#languagesettings",
                            onDirty: function (isDirty) {
                                if (!dialog) {
                                    return;
                                }

                                dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", !isDirty);
                            }
                        });

                        dialog = new Dialog({
                            dialogClass: "epi-dialog-portrait epi-dialog-portrait__autosize epi-dialog--wide",
                            defaultActionsVisible: true,
                            confirmActionText: sharedResources.action.save,
                            content: content,
                            title: commandResources.label
                        });

                        dialog.addValidator(function () {
                            var deferred = new Deferred();
                            model.saveLanguageSettings(model.settings)
                                .then(function (response) {
                                    model.onReadOnly(response.isReadOnly);
                                    dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", response.isReadOnly);

                                    if (response.messageModel && response.messageModel.text) {
                                        model.onMessage(response.messageModel);
                                    } else {
                                        topic.publish("/epi/cms/contentdata/updated", {
                                            contentLink: contentLink,
                                            recursive: true
                                        });

                                        dialog.hide();
                                    }

                                    return deferred.resolve([]);
                                }.bind(this));
                            return deferred.promise;
                        }.bind(this));

                        dialog.show();
                        dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", true);
                        model.onReadOnly(settings.isReadOnly);
                        model.onMessage(settings.messageModel);

                    }.bind(this));
                }.bind(this));
            }.bind(this));
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var contentData = this.model.contentData;
            var hasAdminAccess =
                ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Administer);

            this.set("canExecute", contentData.capabilities.languageSettings && hasAdminAccess);
        }
    });
});
