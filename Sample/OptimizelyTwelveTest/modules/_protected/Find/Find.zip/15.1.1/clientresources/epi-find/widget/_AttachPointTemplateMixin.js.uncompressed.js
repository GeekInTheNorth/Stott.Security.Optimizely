define("epi-find/widget/_AttachPointTemplateMixin", [
    "dojo/_base/declare"
], function (declare) {

    // module:
    //      epi-find/widget/_AttachPointTemplateMixin

    return declare([], {

        // tag: string
        //      The HTML tagname to insert around the templates.
        tag: "strong",

        createAttachPointTemplate: function(templatedStrings) {
            var result = {};
            for(var i in templatedStrings) {
                if (typeof templatedStrings[i] === "string" || templatedStrings[i] instanceof String) {
                    result[i] = templatedStrings[i].replace(/\{(.*?)\}/g,
                        "<"+this.tag+" data-dojo-attach-point="+i+"$1>-</"+this.tag+">");
                }
                // TODO: deep scan?
            }
            return result;
        }
    });
});