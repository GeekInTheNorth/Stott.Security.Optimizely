define("epi-find/widget/_SiblingFocusMixin", [
    "dojo/_base/declare",
    "dojo/_base/array",
    "dijit/dijit",
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/focus"
],
function (declare, array,
    dijit, _WidgetBase, _Container, focusUtil
) {

    // module:
    //      epi-find/widget/_SiblingHasFocus

    return declare([], {
        // summary: 
        //     Sibling has focus mixin
        // desciption:
        //     This mixin is used to determine whether any of the siblings of a widget has focus 

        siblingWithFocus: function() {
            var parent = this.getParent();
            if (!parent) {
                return;
            }
            var siblings = parent.getChildren();
            for(var i=0,j=focusUtil.activeStack.length;i<j;i+=1) {
                var focusedWidget = dijit.byId(focusUtil.activeStack[i]);
                if(array.indexOf(siblings, focusedWidget) > -1) {
                    return focusedWidget;
                }
            }
        },

        onBlurToSibling: function(/* _Widget */ focusedSibling) {},

        onFocus: function () {
            var parent = this.getParent();
            if (!parent) {
                return;
            }
            var siblings = parent.getChildren();
            for(var i=0,j=siblings.length;i<j;i+=1) {
                if(siblings[i] !== this && siblings[i].onBlurToSibling) {
                    siblings[i].onBlurToSibling();
                }
            }
        },

        onBlur: function () {
            var focusedSibling = this.siblingWithFocus();
            if(focusedSibling) {
                this.onBlurToSibling(focusedSibling);
            }
        }

    });
});