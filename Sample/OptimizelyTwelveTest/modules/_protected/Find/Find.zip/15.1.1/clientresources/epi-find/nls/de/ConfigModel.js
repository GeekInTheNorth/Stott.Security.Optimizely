//>>built
define("epi-find/nls/de/ConfigModel",{"configErrorMessage":"Fehler beim Lesen der Konfiguration"});