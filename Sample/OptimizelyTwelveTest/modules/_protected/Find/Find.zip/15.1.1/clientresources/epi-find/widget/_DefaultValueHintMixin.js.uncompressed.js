define("epi-find/widget/_DefaultValueHintMixin", [
    "dojo/_base/declare"
],
function(declare) {
    //  summary:
    //      A mixin for TextBox/TextArea based widgets that accepts a defaultValue that is used as a placeholder.
    //      If text in the widget equals to the defaultValue, then widgets value attribute returns empty string.

    // module:
    //      epi-find/widget/_DefaultValueHintMixin

    return declare(null, {
        defaultValue: null,
        _setDefaultValueAttr: function(value) {
            // save original value of the widgets "value" attribute
            var oldValue = this.get("value"),
            // A bit invasive: save current watch callbacks and nullify them in order to
            // prevent "watches" from firing while we changing the "value" property
                watchCallbacks = this._watchCallbacks;
            this._watchCallbacks = null;

            // Run the default value via widgets "value" attribute setter
            this.set("value", value);
            // use "value" after possible transformations in the setter
            this._set("defaultValue", this.value);
            // show default value as a placeholder
            this.set("placeholder", this.value);
            // restore original attribute value
            this.set("value", oldValue);

            // Restore watch callbacks
            this._watchCallbacks = watchCallbacks;
        },

        onFocus: function() {
            this.inherited(arguments);
            if (!this.value && this.defaultValue) {
                this.set("value", this.defaultValue);
            }
        },

        onBlur: function() {
            this.inherited(arguments);
            if (this.value && this.value === this.defaultValue) {
                this.set("value", "");
            }
        },

        reset: function() {
            this.inherited(arguments);
            this.set("defaultValue", "");
        }
    });
});
