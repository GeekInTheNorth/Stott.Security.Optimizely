define("epi-find/widget/_ContentStatusIndicatorMixin", [
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/dom-attr",
        "dojo/dom-class",
        "dojo/dom-construct",

        "epi-cms/widget/viewmodel/ContentStatusViewModel"

    ],
    function(
        declare,
        lang,
        domAttr,
        domClass,
        domConstruct,
        ContentStatusViewModel

    ) {
        //  summary:
        //      Mixin for ContentSelectors that adds selected content status indicaiton
        // module:
        //      epi-find/widget/_ContentStatusIndicatorMixin

        return declare([], {

            showStatusIcon: false,
            statusIconNode: null,
            statusViewModel: null,

            startup: function() {
                this.inherited(arguments);
                this.watch("contentStatus", lang.hitch(this, function(name, oldValue, value) {
                    if (this.showStatusIcon) {
                        if (value) {
                            this.statusViewModel.set("contentStatus", value);
                        }
                        else {
                            this._resetStatusIcon();
                        }
                    }
                }));
            },

            buildRendering: function() {
                this.inherited(arguments);
                if (this.showStatusIcon) {
                    this.statusIconNode = domConstruct.create("span");
                    domConstruct.place(this.statusIconNode, this.inputContainer, "first");
                    this._resetStatusIcon();
                    this.statusViewModel = new ContentStatusViewModel({autoLoadStatus: false, getCurrentContext: function() {return null;}});

                    this.own(this.statusViewModel.watch("statusIcon", lang.hitch(this, function(name, oldValue, newValue){
                        domClass.remove(this.statusIconNode);
                        domClass.add(this.statusIconNode, newValue);
                    })));
                    this.own(this.statusViewModel.watch("statusMessage", lang.hitch(this, function(name, oldValue, newValue){
                        domAttr.set(this.statusIconNode, "title",  newValue || "");
                    })));
                }
            },

            _resetStatusIcon: function() {
                domClass.remove(this.statusIconNode);
                domClass.add(this.statusIconNode, ["epi-statusIndicatorIcon", "epi-no-background"]);
            }
        });
    });