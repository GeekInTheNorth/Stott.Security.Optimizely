//>>built
define("epi-find/nls/sv/ConfigModel",{"configErrorMessage":"Problem vid inläsning av configuration."});