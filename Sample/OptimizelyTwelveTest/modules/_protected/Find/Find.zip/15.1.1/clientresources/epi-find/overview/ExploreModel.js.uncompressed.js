﻿define("epi-find/overview/ExploreModel", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/Deferred",
    "dojo/when",
    "dojo/aspect",
    "dojo/_base/config",
    "dojo/Stateful",
    "dojo/store/util/QueryResults",
    "dojo/store/Memory",

    "../store/StoreFactory",

    "../util/search"

],
function (array,
		  declare,
          lang,
          Deferred,
          when,
          aspect,
          config,
          Stateful,
          QueryResults,
          Memory,
          StoreFactory,
          search) {

    return declare([Stateful], {
        // summary:
        //      Explore view model.

        store: null,

        queryInProgress: false,

        query: null,

        facetSize: 100,

        _queryGetter: function () {
            if (!this.query) {
                this._buildQuery();
            }
            return this.query;
        },

        _querySetter: function (value) {
            this.query = value;
        },

        searchText: null,

        _searchTextGetter: function () {
            return this.searchText;
        },

        _searchTextSetter: function (value) {
            if (value !== this.searchText) {
                this.searchText = value;
                if (value) {
                    // reset sort if there is a search text in order to sort by score
                    this.set("sort", []);
                }
                this._buildQuery();
            }
        },

        typeFilter: null,

        _typeFilterGetter: function () {
            return this.typeFilter;
        },

        _typeFilterSetter: function (value) {
            if (value !== this.typeFilter) {
                this.typeFilter = value;
                this._buildQuery();
            }
        },

        querySort: null,
        sort: null,
        _sortSetter: function(value) {
            var direction;
            if (!value || !value.length) {
                this.querySort = [];
            }
            else if (value[0].attribute === "name") {
                direction = value[0].descending ? "desc": "asc";
                this.querySort = [					
					{
                        "SearchTitle$$string":{
                            "order": direction,
                            "ignore_unmapped" : true
                        },
						"Name$$string":{
							"order": direction,
							"ignore_unmapped" : true
						}
                    }
                ];
            }
            else if (value[0].attribute === "type") {
                direction = value[0].descending ? "desc" : "asc";
                this.querySort = [
                    {
                        "_TypeShortName":{
                            "order": direction,
                            "ignore_unmapped" : true
                        },
                        "$type":{
                            "order": direction,
                            "ignore_unmapped" : true
                        }
                    }
                ];
            }
            this._buildQuery();
            this.sort = value;
        },

        totalDocuments: null,

        constructor: function() {
            var self = this;
            // Have to clone in order to use aspect
            this.store = StoreFactory.createElasticSearchStore();
            this.sort = [];
            this.typeFacetStore = new Memory({ idProperty: "term" });

            // Updating model when query is completed
            aspect.around(this.store, "query", function (originalQuery) {

                return function(query, options) {

                    var deferred = new Deferred();

                    if (!self._isLastQuery(query)) {
                        deferred.cancel();
                        return new QueryResults(deferred.promise);
                    }

                    self.set("queryInProgress", true);

                    var originalResult = originalQuery.apply(self.store, arguments);
                    var result = new QueryResults(originalResult);

                    when (originalResult, function (data) {
                        if (!self._isLastQuery(query)) {
                            deferred.cancel();
                            return;
                        }

                        // Updating total number of documents
                        when(originalResult.total, function (total) {
                            self.set("totalDocuments", total);
                        });
                        // Updating available document types
                        when(originalResult.facets, function (facets) {
                            var terms = facets.type.terms;
                            if (self.typeFilter && self.typeFilter.length) { // if the filter by type is set ...
                                array.forEach(self.typeFilter, function (filter) {
                                    // ... and a type in the filter is not in the list of types returned by facets
                                    if (!array.some(terms, function (item) {
                                            return item.term === filter;
                                        })) {
                                        terms.push({term: filter, count: 0}); // ... add a type from the filter to the types list
                                    }
                                });
                            }

                            self.typeFacetStore.setData(terms);
                            self.set("queryInProgress", false);
                        });

                        deferred.resolve(data);

                    }, function(err){
                        console.error(err);
                        // set queryInProgress to false to make search event continue working when rejected.
                        self.set("queryInProgress", false);
                    });

                    return result;

                };
            });
        },

        init: function () {
            //  summary:
            //      Sets the model properties to initial state.
            //      This method should be called when widgets are instantiated and subscribed on model updates,
            //      so that when this method is called dependent widgets will get initial values from the model.
            this.searchText = null;
            this.typeFilter = null;
            this._buildQuery();
        },

        getShortTypeName: function(typeName) {
            if (typeName && typeName.split) {
                var fullTypeName = typeName.split(",")[0], // take the full type name without assembly name
                    typeParts = fullTypeName.split("."),
                    shortType = typeParts[typeParts.length-1]; // take class name from full type name
                return shortType;
            }
            else {
                return typeName;
            }
        },

        _isLastQuery: function(query) {
            var q1 = JSON.stringify(this.get("query"));
            var q2 = JSON.stringify(query);
            return q1 === q2;
        },

        _buildQuery: function() {
            //  summary:
            //      Builds ElasticSearch query based on model parameters.
            var query;
            if (this.searchText && this.searchText !== "") {
                query = { query: { query_string: { query: search.escapeQueryStringQuery(this.searchText, true) } }, partial_fields: { partial_source: { include: "*", exclude: "*$$attachment" } } };
            } else {
                query = { query: { query_string: { query: "*:*" } }, partial_fields: { partial_source: { include: "*", exclude: "*$$attachment" } } };
            }
            query.facets = { type: { terms: { "field": "$type", size: this.facetSize } } };

            if (this.typeFilter && this.typeFilter.length) {
                query.filter = { terms: { "$type": this.typeFilter } };
            }

            if (this.querySort && this.querySort.length) {
                query.sort = this.querySort;
            }

            this.query = query;
        },

        resetPaging: function () {
            if (this.query) {
                if (this.query.from) {
                    this.query.from = null;
                }
                if (this.query.size) {
                    this.query.size = null;
                }
            }
        }
    });
});
