define("epi-find/widget/_StyleFocusMixin", [
    "dojo/dom-class",
    "dojo/_base/declare",
    "dijit/_FocusMixin"
], function (domClass, declare, _FocusMixin) {

    // module:
    //      epi-find/widget/_StyleFocusMixin

    // Copied from "epi/shell/widget/_FocusableMixin"

    return declare( _FocusMixin, {
        onFocus: function () {
            // summary:
            //      Called when the widget becomes "active" because
            //      it or a widget inside of it either has focus, or has recently
            //      been clicked.
            this.inherited(arguments);
            domClass.add(this.domNode, "epi-focused");
        },
        onBlur: function () {
            // summary:
            //      Called when the widget stops being "active" because
            //      focus moved to something outside of it, or the user
            //      clicked somewhere outside of it, or the widget was
            //      hidden.
            this.inherited(arguments);
            domClass.remove(this.domNode, "epi-focused");
        }
    });
});