define("epi-find/widget/_DisabledViewMixin", [
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",

    "epi-saas-base/widgets/NotificationBar",

    "dojo/i18n!./nls/_DisabledViewMixin"
], function (
    config,
    declare,
    lang,
    domClass,

    NotificationBar,

    i18n
    ) {
    return declare([], {
        // summary:
        //     Allows to enable and disable views.

        // disabledView: Boolean
        //		Should this widget respond to user actions
        disabledView: false,

        _setDisabledViewAttr: function(/*Boolean*/ disabled) {
            // summary:
            //		Sets the disable state of the view widget.
            // tags:
            //		protected

            if (disabled === this.disabledView) {
                return;
            }
            this._set("disabledView", disabled);

            if(this._created) {
                if (disabled) {
                    this.disable();
                }
                else {
                    this.enable();
                }
            }
        },

        //  disabledNode: Object
        //    DOM node of the area that should be disabled.
        disabledNode: null,

        _getDisabledNodeAttr: function () {
            // summary:
            //		Gets the DOM node of the area that should be disabled. Can be overriden in order to change default behaviour.
            // returns:
            //      By default widget DOM node is returned.
            // tags:
            //		protected

            return this.disabledNode || this.domNode;
        },

        //  notificationParent: Object
        //    Widget where disabled notification should be added.
        notificationParent: null,

        _getNotificationParentAttr: function () {
            // summary:
            //		Gets the widget that should be used as parent where disabled notification should be added.
            //      Can be overriden in order to change default behaviour.
            // returns:
            //      By default this widget is returned.
            // tags:
            //		protected

            return this.notificationParent || this;
        },

        //  notificationPosition: Integer
        //    Integer position where disabled notification should be added in the parent widget.
        notificationPosition: null,

        _getNotificationPositionAttr: function () {
            // summary:
            //		Gets the position where disabled notification should be added in the parent widget.
            //      Can be overriden in order to change default behaviour.
            // returns:
            //      By default 0 is returned, so notification bar should be added on the first place inside parent widget.
            // tags:
            //		protected

            return this.notificationPosition || 0;
        },

        // notificationClass: String
        //      CSS class that should be used for notification bar.
        notificationClass: "epi-notificationBar-disabledView",

        // disabledClass: String
        //      CSS class that should be used for the DOM node that visually represents disabled area.
        disabledClass: "epi-pane__content--disabled",

        // _disabledNotification: Object
        //      Disabled notification bar widget.
        _disabledNotification: null,

        disable: function () {
            //  summary:
            //    Disables the view by adding overlay and notification bar.
            //    This method can be overriden if additional custom behaviour is required when disabling the view.
            //
            // tags:
            //		public

            var disabledNode = this.get("disabledNode");
            if (disabledNode) {
                domClass.add(disabledNode, this.disabledClass);
            }

            var position = this.get("notificationPosition");
            var parent = this.get("notificationParent");

            if (this._disabledNotification || !parent) {
                return;
            }
            this._disabledNotification = this._createNotification();
            this.own(this._disabledNotification);

            this._disabledNotification.placeAt(parent, position);
        },

        enable: function () {
            //  summary:
            //    Enables the view by removing overlay and notification bar.
            //    This method can be overriden if additional custom behaviour is required when enabling the view.
            //
            // tags:
            //		public

            if (this._disabledNotification) {
                this._disabledNotification.destroy();
            }
            this._disabledNotification = null;

            var disabledNode = this.get("disabledNode");
            if (disabledNode) {
                domClass.remove(disabledNode, this.disabledClass);
            }
        },

        postCreate: function () {
            //  summary:
            //    Overriden in order to disable the view if it is required
            //
            // tags:
            //		public

            this.inherited(arguments);
            if (this.disabledView) {
                this.disable();
            }
        },

        _createNotification: function () {
            //  summary:
            //    Creates notification bar that should be displayed on disabled views.
            //    This method can be overriden if custom notification widget should be created for disabled views.
            //
            // tags:
            //		protected

            var notification = new NotificationBar({
                "class": this.notificationClass
            });

            var orderFindUrl = i18n["orderFindUrl"] ||
                ( config.find && config.find.orderFindUrl ? config.find.orderFindUrl : "http://episerver.com" );

            notification.addNotification({
                message: lang.replace(i18n.disabledMessage, [ orderFindUrl ]),
                type: "info",
                persistent: true
            });

            return notification;
        }

    });
});
