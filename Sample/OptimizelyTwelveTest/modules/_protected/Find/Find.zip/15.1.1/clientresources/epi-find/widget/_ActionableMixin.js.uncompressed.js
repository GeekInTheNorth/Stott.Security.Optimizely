define("epi-find/widget/_ActionableMixin", [
    "dojo/_base/declare"
],
function(declare) {
    //  summary:
    //      A mixin that should be used for anything taking part of navigation.
    //      An actionable is:
    //          * Something that maintains a list of actions that can be taken.
    //          * When urged to, choses one of the child-Actionables based on what is on top on the provided action stack
    //              and delegates further action to that child-Actionable.
    //      If an actual action should be taken, any inheriting object can override takeAction.

    // module:
    //      epi-find/widget/_ActionableMixin

    return declare([], {

        _actions: null,
        _previousActionable: null,

        // previousActionFallback: Boolean
        //       Indicates whether previous action should be taken if unable to resolve required action by arguments
        previousActionFallback: false,

        currentAction: null,

        registerAction: function( /* string */ name, /* _ActionableMixin | function */ actionable) {
            this._actions = this._actions || {};
            this._actions[name] = actionable;
        },

        findActionable: function(context) {
            for (var name in this._actions) {
                var actionable = this._actions[name];
                if (name === context) {
                    return actionable;
                }
            }
            return null;
        },

        takeAction: function(actions, params) {
            if (!actions) {
                return null;
            }
            if (!(actions instanceof Array)) {
                actions = [actions];
            }
            var context = actions.shift();
            var actionable = this.findActionable(context);
            if (actionable) {
                this._previousActionable = actionable;
                this._executeActionable(actionable, actions, params);
                if (actionable.currentAction) {
                    this.currentAction = context + "/" + actionable.currentAction;
                }
                else {
                    this.currentAction = context;
                }
                return actionable;
            }
            else if (this.previousActionFallback && this._previousActionable) {
                this._executeActionable(this._previousActionable, actions, params);
                return this._previousActionable;
            }

            // TODO: How do we want to handle route failures?
            return null;
        },

        _executeActionable: function (actionable, actions, params) {
            if (actionable.takeAction) {
                return actionable.takeAction(actions, params);
            } else {
                actionable(actions, params);
                return actionable;
            }
        }
    });
});