define("epi-addon-tinymce/plugins/epi-paste/paste-confirmation-dialog", [
    "dojo/_base/declare",
    "dojo/Deferred",

    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi/shell/widget/dialog/_DialogContentMixin",
    "epi/shell/DialogService",
    "epi/shell/widget/_ActionProviderWidget",

    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epipaste"
],
function (
    declare,
    Deferred,

    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _DialogContentMixin,
    dialogService,

    _ActionProviderWidget,

    pluginResources
) {
    var DialogContent = declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ActionProviderWidget, _DialogContentMixin], {
        templateString: "<div>Choose to keep or remove formatting in the pasted content.</div>",

        getActions: function () {
            var self = this;

            this._actions = [
                {
                    name: "cancel",
                    label: pluginResources.dialog.removeformatting,
                    settings: { type: "button" },
                    action: function () {
                        self.executeDialog("Remove");
                    }
                },
                {
                    name: "save",
                    label: pluginResources.dialog.keepformatting,
                    settings: { type: "button" },
                    action: function () {
                        self.executeDialog("Keep");
                    }
                }
            ];

            return this._actions;
        }
    });

    function showConfirmation() {
        var result = new Deferred();
        var content = new DialogContent();

        dialogService.dialog({
            defaultActionsVisible: false,
            content: content,
            title: pluginResources.dialog.title,
            dialogClass: "tinymce-formatting-confirmation"
        }).then(function (value) {
            result.resolve(value);
        }).always(function () {
            content.destroy();
        });

        return result.promise;
    }

    return showConfirmation;
});
