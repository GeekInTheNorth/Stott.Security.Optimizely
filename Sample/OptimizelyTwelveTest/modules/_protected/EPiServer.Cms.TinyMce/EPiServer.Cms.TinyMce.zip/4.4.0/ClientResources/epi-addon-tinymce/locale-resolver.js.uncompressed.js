define("epi-addon-tinymce/locale-resolver", [], function () {
    var availableLanguages = ["da-dk", "de-de", "es-es", "fi-fi", "fr-fr", "it-it", "ja-jp", "nb-no", "nl-nl", "no", "sv-se", "zh-cn"];

    function getCountryCode(cultureInfo) {
        var index = (cultureInfo || "").indexOf("-");
        if (index === -1) {
            return cultureInfo;
        }
        return (cultureInfo || "").substring(0, index);
    }

    function localeResolver(locale) {
        locale = (locale || "").toLowerCase();


        var availableCountryCodes = availableLanguages.map(function (x) {
            return getCountryCode(x);
        });

        var localeCountryCode = getCountryCode(locale);

        var mappedIndex = availableCountryCodes.indexOf(localeCountryCode);
        if (mappedIndex !== -1) {
            return availableLanguages[mappedIndex];
        }

        return "en-us";
    }

    return localeResolver;
});
